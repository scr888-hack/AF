
        if op.type == 5:
            print ("[ 5 ] NOTIFIED ADD CONTACT")
            if settings["autoAdd"] == True:
                maxgie.sendMessage(op.param1, "สวัสดี {} ขอบคุณที่แอดมา".format(str(nadya.getContact(op.param1).displayName)))
#                nadya.sendMessage(op.param1, str(settings["welcome"]))
                nadya.sendMessage(op.param1, str(settings["สน"]))
        if op.type == 5:
            if settings["autoblock"] == True:
              if op.param2 in admin:
                  return
              nadya.sendMessage(op.param1,tagadd["b"])
              nadya.blockContact(op.param1)
              print ("[ 5 ] AUTO BLOCK")        
        if op.type == 13:
            print ("[ 13 ] NOTIFIED INVITE GROUP")
            group = nadya.getGroup(op.param1)
            if settings["autoJoin"] == True:
                nadya.acceptGroupInvitation(op.param1)
#                nadya.sendMessage(op.param1, str(settings["welcome"]))
                nadya.sendMessage(op.param1, str(settings["commet"]))

                elif msg.text in ('sp','Sp','สปีด'):
                    start = time.time()
                    nadya.sendMessage(to, "รอสักครู่...")
                    elapsed_time = time.time() - start
                    nadya.sendMessage(to,format(str(elapsed_time)))
                elif text.lower() == 'รีบอท':
                  if msg._from in admin and Owner:
                    nadya.sendMessage(to, "รอสักครู่...")
                    time.sleep(5)
                    nadya.sendMessage(to, "เรียบร้อย")
                    restartBot()
                elif text.lower() == 'บอทออน':
                    timeNow = time.time()
                    runtime = timeNow - botStart
                    runtime = format_timespan(runtime)
                    nadya.sendMessage(to, "ระยะเวลาการทำงานของบอท {}".format(str(runtime)))
                elif text.lower() == 'status':
                    try:
                        ret_ = "╔══[ Status ]"
                        if settings["protect"] == True: ret_ += "\n╠ Protect ✅"
                        else: ret_ += "\n╠ Protect ❌"
                        if settings["qrprotect"] == True: ret_ += "\n╠ Qr Protect ✅"
                        else: ret_ += "\n╠ Qr Protect ❌"
                        if settings["inviteprotect"] == True: ret_ += "\n╠ Invite Protect ✅"
                        else: ret_ += "\n╠ Invite Protect ❌"
                        if settings["cancelprotect"] == True: ret_ += "\n╠ Cancel Protect ✅"
                        else: ret_ += "\n╠ Cancel Protect ❌"
                        if settings["autoAdd"] == True: ret_ += "\n╠ Auto Add ✅"
                        else: ret_ += "\n╠ Auto Add ❌"
                        if settings["autoJoin"] == True: ret_ += "\n╠ Auto Join ✅"
                        else: ret_ += "\n╠ Auto Join ❌"
                        if settings["autoLeave"] == True: ret_ += "\n╠ Auto Leave ✅"
                        else: ret_ += "\n╠ Auto Leave ❌"
                        if settings["autoRead"] == True: ret_ += "\n╠ Auto Read ✅"
                        else: ret_ += "\n╠ Auto Read ❌"
                        if settings["checkSticker"] == True: ret_ += "\n╠ Check Sticker ✅"
                        else: ret_ += "\n╠ Check Sticker ❌"
                        if settings["detectMention"] == True: ret_ += "\n╠ Detect Mention ✅"
                        else: ret_ += "\n╠ Detect Mention ❌"
                        ret_ += "\n╚══[ Status ]"
                        nadya.sendMessage(to, str(ret_))
                    except Exception as e:
                        nadya.sendMessage(msg.to, str(e))
#-------------------------------------------------------------------------------
                elif text.lower() == 'เช็ค':
                  if msg._from in admin:
                    try:
                        ret_ = "╔════[ ❋การตั้งค่า❋ ]═════┓"
                        if settings["autoAdd"] == True: ret_ += "\n╠❋ ตอบรับเพื่อนออโต้ ✅"
                        else: ret_ += "\n╠❋ ตอบรับเพื่อนออโต้ ❌"
                        if settings["autoBlock"] == True: ret_ += "\n╠❋ ออโต้บล็อคเปิด ✅"
                        else: ret_ += "\n╠❋ ออโต้บล็อคปิด   ❌ "
                        if settings["autoJoinTicket"] == True: ret_ += "\n╠❋ มุดลิ้งเปิด ✅"
                        else: ret_ += "\n╠❋ มุดลิ้งปิด ❌ "
                        if settings["autoJoin"] == True: ret_ += "\n╠❋ เข้ากลุ่มออโต้เปิด ✅"
                        else: ret_ += "\n╠❋ เข้ากลุ่มออโต้ปิด ❌ "
                        if settings["Api"] == True: ret_ += "\n╠❋ ข้อความApiเปิด ✅"
                        else: ret_ += "\n╠❋ ข้อความApiปิด ❌ "
                        if settings["Aip"] == True: ret_ += "\n╠❋ ตรวจคำสั่งบินเปิด✅"
                        else: ret_ += "\n╠❋ ตรวจคำสั่งบินปิด ❌ "
                        if settings["Wc"] == True: ret_ += "\n╠❋ ข้อความต้อนรับเปิด ✅"
                        else: ret_ += "\n╠❋ ข้อความต้อนรับปิด  ❌ "
                        if settings["Lv"] == True: ret_ += "\n╠❋ ข้อความคนออกเปิด ✅"
                        else: ret_ += "\n╠❋ ข้อความคนออกปิด ❌ "
                        if settings["Nk"] == True: ret_ += "\n╠❋ ข้อความแจ้งเตือนคนลบเปิด ✅"
                        else: ret_ += "\n╠❋ ข้อความแจ้งเตือนคนลบปิด ❌ "
                        if settings["autoCancel"]["on"] == True:ret_+="\n╠❋ ปฏิเสธเชิญที่มีสมาชิกต่ำกว่า: " + str(settings["autoCancel"]["members"]) + " → ✅"
                        else: ret_ += "\n╠❋ ปฏิเสธกลุ่มเชิญปิด    ❌ "
                        if settings["autoLeave"] == True: ret_ += "\n╠❋ ออกแชทรวมออโต้เปิด✅"
                        else: ret_ += "\n╠❋ ออกแชทรวมออโต้ปิด ❌ "
                        if settings["autoRead"] == True: ret_ += "\n╠❋ อ่านออโต้เปิด ✅"
                        else: ret_ += "\n╠❋ อ่านออโต้ปิด ❌"
                        if settings["checkContact"] == True: ret_ += "\n╠❋ อ่านคทเปิด ✅"
                        else: ret_ += "\n╠❋ อ่านคทปิด   ❌ "
                        if settings["checkPost"] == True: ret_ += "\n╠❋ เช็คโพสเปิด ✅"
                        else: ret_ += "\n╠❋ เช็คโพสปิด   ❌ "
                        if settings["checkSticker"] == True: ret_ += "\n╠❋ เช็คStickerเปิด ✅"
                        else: ret_ += "\n╠❋ เช็คStickerปิด  ❌ "
                        if settings["detectMention"] == True: ret_ += "\n╠❋ ตอบกลับคนแทคเปิด ✅"
                        else: ret_ += "\n╠❋ ตอบกลับคนแทคปิด ❌ "
                        if settings["potoMention"] == True: ret_ += "\n╠❋ แสดงภาพ+คท คนแทคเปิด ✅"
                        else: ret_ += "\n╠❋ แสดงภาพ+คท คนแทค ปิด ❌ "
                        if settings["kickMention"] == True: ret_ += "\n╠❋ เตะคนแทคเปิด ✅"
                        else: ret_ += "\n╠❋ เตะคนแทคปิด ❌ "
                        if settings["delayMention"] == True: ret_ += "\n╠❋ แทคกลับคนแทคเปิด ✅"
                        else: ret_ += "\n╠❋ แทคกลับคนแทคปิด ❌ "
                        if settings["inviteprotect"] == True: ret_ += "\n╠❋ กันเชิญเปิด ✅"
                        else: ret_ += "\n╠❋ กันเชิญปิด ❌ "
                        if settings["cancelprotect"] == True: ret_ += "\n╠❋ กันยกเชิญเปิด ✅"
                        else: ret_ += "\n╠❋ กันยกเชิญปิด ❌ "
                        if settings["protect"] == True: ret_ += "\n╠❋ ป้องกันเปิด ✅"
                        else: ret_ += "\n╠❋ ป้องกันปิด ❌ "
                        if settings["qrprotect"] == True: ret_ += "\n╠❋ ป้องกันเปิดลิ้งเปิด ✅"
                        else: ret_ += "\n╠❋ ป้องกันเปิดลิ้งปิด ❌ "
                        if settings["qrprotect"] == True: ret_ += "\n╠❋ ป้องกันสมาชิกเปิด ✅"
                        else: ret_ += "\n╠❋ ป้องกันสมาชิกปิด ❌ "
                        if settings["inviteprotect"] == True: ret_ += "\n╠❋ ป้องกันคนนอกเข้ากลุ่ม ✅"
                        else: ret_ += "\n╠❋ ป้องกันคนนนอกเข้ากลุ่ม ❌ "
                        ret_ += "\n╚════[Hack Scan Win]═════┛"
                        nadya.sendMessage(to, str(ret_))
                    except Exception as e:
                        nadya.sendMessage(msg.to, str(e))
#-------------------------------------------------------------------------------
                elif 'สน: ' in msg.text:
                  if msg._from in admin and Owner:
                     spl = msg.text.replace('สน: ','')
                     if spl in [""," ","\n",None]:
                         nadya.sendMessage(msg.to, "❋ตั้งข้อความเรียบร้อยแล้ว❋")
                     else:
                          settings["สน"] = spl
                          nadya.sendMessage(msg.to, "เรียบร้อย❋\n\n{}".format(str(spl)))
#-------------------------------------------------------------------------------
                elif msg.text.lower().startswith("เพิ่มแอด "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                admin[target] = True
                                f=codecs.open('admin.json','w','utf-8')
                                json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-Bot-☢\nจดจำ\nเรียบร้อยคับ")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")

                elif msg.text.lower().startswith("ลบแอด "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                del admin[target]
                                f=codecs.open('admin.json','w','utf-8')
                                json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-Bot-☢\nลบออก\nเรียบร้อย")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")
#-------------------------------------------------------------------------------
                elif msg.text.lower().startswith(".เพิ่มแอด "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                Owner[target] = True
                                f=codop0ecs.open('Owner.json','w','utf-8')
                                json.dump(Owner, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-Bot-☢\nจดจำ\nเรียบร้อยคับ")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")
                elif msg.text.lower().startswith(".เพิ่มmid "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                mid[target] = True
                                f=codop0ecs.open('F__mid.json','w','utf-8')
                                json.dump(mid, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-เรียบร้อยคับ")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")

                elif msg.text.lower().startswith(".ลบแอด "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                del Owner[target]
                                f=codecs.open('Owner.json','w','utf-8')
                                json.dump(Owner, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-Bot-☢\nลบออก\nเรียบร้อย")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")
                elif msg.text.lower().startswith("เพิ่มแชท "):
                    if msg._from in Owner:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            try:
                                del mid[target]
                                f=codecs.open('max.json','w','utf-8')
                                json.dump(mid, f, sort_keys=True, indent=4,ensure_ascii=False)
                                nadya.sendMessage(msg.to,"☢-Bot-☢\nลบออก\nเรียบร้อย")
                            except:
                                pass
                    else:
                        nadya.sendMessage(msg.to,"Owner Permission Required")
#-------------------------------------------------------------------------------
                elif text.lower() == 'เปิดป้องกัน':
                    if msg._from in admin:
                        if settings["protect"] == True:
                            if settings["lang"] == "JP":
                                nadya.sendMessage(msg.to,"➲ Protection Already On")
                            else:
                                nadya.sendMessage(msg.to,"➲ Protection Set To On")
                        else:
                            settings["protect"] = True
                            if settings["lang"] == "JP":
                                nadya.sendMessage(msg.to,"➲ Protection Set To On")
                            else:
                                nadya.sendMessage(msg.to,"➲ Protection Already On")
                                
                elif text.lower() == 'ปิดป้องกัน':
                    if msg._from in admin:
                        if settings["protect"] == False:
                            if settings["lang"] == "JP":
                                nadya.sendMessage(msg.to,"➲ Protection Already Off")
                            else:
                                nadya.sendMessage(msg.to,"➲ Protection Set To Off")
                        else:
                            settings["protect"] = False
                            if settings["lang"] == "JP":
                                nadya.sendMessage(msg.to,"➲ Protection Set To Off")
                            else:
                                nadya.sendMessage(msg.to,"➲ Protection Already Off")
#-------------------------------------------------------------------------------
                elif text.lower() == 'เปิดระบบป้องกัน':
                    if msg._from in admin:
                        group = nadya.getGroup(to)
                        settings["protect"] = True
                        settings["qrprotect"] = True
                        settings["inviteprotect"] = True
                        settings["cancelprotect"] = True
                        settings["autoRead"] = True
                        settings["autoAdd"] = True
                        settings["autoJoinTicket"] = True
                        settings["Nk"] = True
                        settings["Lv"] = True
                        settings["Wc"] = True
                        settings["autoBlock"] = True
                        settings["Aip"] = True
                        settings["detectMention"] = True
                        nadya.sendMessage(msg.to,"➲ All Protect Set To On")
                    else:
                        nadya.sendMessage(msg.to,"Just for Owner")
                        		            
                elif text.lower() == 'ปิดระบบป้องกัน':
                    if msg._from in admin:
                        group = nadya.getGroup(to)
                        settings["protect"] = False
                        settings["qrprotect"] = False
                        settings["inviteprotect"] = False
                        settings["cancelprotect"] = False
                        nadya.sendMessage(msg.to,"➲ All Protect Set To Off")
                    else:
                        nadya.sendMessage(msg.to,"Just for Owner")
                elif text.lower() == 'เปิดลิ้ง':
                    if msg._from in admin:
                        group = nadya.getGroup(to)
                        if group.preventedJoinByTicket == False:
                            nadya.sendMessage(to, "เปิดลิ้งเรียบร้อย")
                        else:
                            group.preventedJoinByTicket = False
                            nadya.updateGroup(group)
                            nadya.sendMessage(to, "เปิดลิ้งเรียบร้อย")
                elif text.lower() == 'ปิดลิ้ง':
                    if msg._from in admin:
                        group = nadya.getGroup(to)
                        if group.preventedJoinByTicket == True:
                            nadya.sendMessage(to, "ปิดลิ้งเรียบร้อย")
                        else:
                            group.preventedJoinByTicket = True
                            nadya.updateGroup(group)
                            nadya.sendMessage(to, "ปิดลิ้งเรียบร้อย")
#-------------------------------------------------------------------------------
                elif msg.text in ["เปิดแทค"]:
                  if msg._from in admin:
                    settings['detectMention'] = True
                    nadya.sendMessage(msg.to,"Respon enabled.")

                elif msg.text in ["ตรวจสอบคำหยาบ"]:
                  if msg._from in admin:
                    settings["Aip"] = True
                    nadya.sendMessage(msg.to,"เปิดระบบตรวจสอบคำหยาบกับบอทบิน  ^ω^")

                elif msg.text in ["ปิดตรวจสอบคำหยาบ"]:
                  if msg._from in admin:
                    settings["Aip"] = False
                    nadya.sendMessage(msg.to,"ปิดระบบตรวจสอบคำหยาบกับบอทบินแล้วʕ•ﻌ•ʔ")

                elif msg.text in ["เปิดพูด"]:
                  if msg._from in admin:
                    settings["Api"] = True
                    nadya.sendMessage(msg.to,"เปิดระบบApiข้อความ")

                elif msg.text in ["ปิดพูด"]:
                  if msg._from in admin:
                    settings["Api"] = False
                    nadya.sendMessage(msg.to,"ปิดระบบApiข้อความแล้ว")
#==============================================================================#
                elif "ปวดตับ" in msg.text:
                     if msg._from in Owner:
                         _name = msg.text.replace("ปวดตับ","")
                         gs = nadya.getGroup(receiver)
                         nadya.sendMessage(receiver,"ต้องรีบไปหาหมอ ô")
                         targets = []
                         for g in gs.members:
                             if _name in g.displayName:
                                 targets.append(g.mid)
                         if targets == []:
                             nadya.sendMessage(receiver,"Not found.")
                         else:
                             for target in targets:
                                 if not target in admin:
                                     try:
                                         k = [nadya,ki,ki2,ki3,ki4]
                                         random.choice(k).kickoutFromGroup(receiver,[target])
                                         print ((receiver,[g.mid]))
                                     except:
                                         nadya.sendMessage(receiver,"ไปก่อนนะ")
                                         print ("คลีนิค ปิดเรียบร้อย")
#==============================================================================#

                elif text.lower() == 'ติ้ก on':
                    settings["checkSticker"] = True
                    nadya.sendMessage(to, "❥เปิดระบบเช็คสติ้กเกอร์ ❋")
                elif text.lower() == 'ติ้ก off':
                    settings["checkSticker"] = False
                    nadya.sendMessage(to, "❥ปิดระบบเช็คสติ้กเกอร์ ❋")
                elif text.lower() == 'เปิดแอด':
                  if msg._from in admin:
                    settings["autoAdd"] = True
                    nadya.sendMessage(to, "เปิดแล้ว!!")
                elif text.lower() == 'ปิดแอด':
                  if msg._from in admin:
                    settings["autoAdd"] = False
                    nadya.sendMessage(to, "ปิดแล้ว!!")
                elif text.lower() == 'เปิดบล็อค':
                  if msg._from in admin:
                    settings["autoBlock"] = True
                    nadya.sendMessage(to, "เปิดใช้งานออโต้บล็อคแล้ว.")
                elif text.lower() == 'ปิดบล็อค':
                  if msg._from in admin:
                    settings["autoBlock"] = False
                    nadya.sendMessage(to, "ปิดใช้งานออโต้บล็อคแล้ว")
                elif text.lower() == 'เปิดลิ้งแชร์':
                  if msg._from in admin:
                    settings["timeline"] = True
                    nadya.sendMessage(to, "เปิดลิ้งแชร์แล้ว.")
                elif text.lower() == 'ปิดลิ้งแชร์':
                  if msg._from in admin:
                    settings["timeline"] = False
                    nadya.sendMessage(to, "ปิดลิ้งแชร์แล้ว.")
                elif text.lower() == 'เปิดตรวจสอบ':
                  if msg._from in admin:
                    settings["checkContact"] = True
                    nadya.sendMessage(to, "ตรวจสอบ สมาชิก ถูกเปิดแล้ว")
                elif text.lower() == 'เปิดตอบ':
                  if msg._from in admin:
                    settings["delayMention"] = True
                    nadya.sendMessage(to, "ตรวจสอบ สมาชิก ถูกปิดแล้ว")
                elif text.lower() == '/กลุ่ม':
                    if msg._from in admin:
                        groups = nadya.groups
                        ret_ = "╔══[ Group List ]"
                        no = 0 + 1
                        for gid in groups:
                            group = nadya.getGroup(gid)
                            ret_ += "\n╠ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                            no += 1
                        ret_ += "\n╚══[ ทั้งหมด {} กลุ่ม ]".format(str(len(groups)))
                        nadya.sendMessage(to, str(ret_))
                elif text.lower() == '/เพื่อน':
                  if msg._from in admin:
                    contactlist = nadya.getAllContactIds()
                    kontak = nadya.getContacts(contactlist)
                    num=1
                    msgs="❋รายชื่อเพื่อนทั้งหมด❋"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.displayName)
                        num=(num+1)
                    msgs+="\n❋รายชื่อเพื่อนทั้งหมด❋\n\nมีดังต่อไปนี้ : %i" % len(kontak)
                    nadya.sendMessage(msg.to, msgs)
                elif msg.text in ["ไอดีเพื่อน"]: 
                  if msg._from in admin:
                    gruplist = nadya.getAllContactIds()
                    kontak = nadya.getContacts(gruplist)
                    num=1
                    msgs="═════════ไอดีเพื่อน═════════"
                    for ids in kontak:
                        msgs+="\n[%i] %s" % (num, ids.mid)
                        num=(num+1)
                    msgs+="\n═════════ไอดีเพื่อน═════════\n\nTotal Friend : %i" % len(kontak)
                    nadya.sendMessage(receiver, msgs)
                elif msg.text.lower().startswith("แปลไทย "):
                    sep = text.split(" ")
                    isi = text.replace(sep[0] + " ","")
                    translator = Translator()
                    hasil = translator.translate(isi, dest='th')
                    A = hasil.text
                    nadya.sendMessage(msg.to, A)
#=======================================================================================
                elif "bk " in msg.text:
                        vkick0 = msg.text.replace("bk ","")
                        vkick1 = vkick0.rstrip()
                        vkick2 = vkick1.replace("@","")
                        vkick3 = vkick2.rstrip()
                        _name = vkick3
                        gs = nadya.getGroup(msg.to)
                        targets = []
                        for s in gs.members:
                            if _name in s.displayName:
                                targets.append(s.mid)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    nadya.kickoutFromGroup(msg.to,[target])
                                    nadya.findAndAddContactsByMid(target)
                                    nadya. inviteIntoGroup(msg.to,[target])
                                except:
                                    pass
                elif "โทร" == msg.text.lower():
                    nadya.inviteIntoGroupCall(msg.to,[uid.mid for uid in nadya.getGroup(msg.to).members if uid.mid != nadya.getProfile().mid])
                    nadya.sendMessage(msg.to,"➠เชิญเข้าร่วมการโทรสำเร็จ (｡◕‿◕｡) ")
#=======================================================================================
                elif msg.text.lower().startswith("bye "):
                    if msg._from in admin:
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"][0]["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           if not target in admin:
                               try:
                                   random.choice(KAC).kickoutFromGroup(msg.to,[target])
                               except:
                                   random.choice(KAC).sendMessage(msg.to,"Error")
#=======================================================================================
                elif text.lower() == 'ล้างบัญชีดำ':
                    if msg._from in admin:
                        settings["blacklist"] = {}
                        nadya.sendMessage(msg.to,"ล้างเรียบร้อย")
                    else:
                        nadya.sendMessage(msg.to,"คุณไม่มีอำนาจสั่ง")
        
                elif text.lower() == 'ล้างmid':
                    if msg._from in admin:
                        settings["mid"] = {}
                        nadya.sendMessage(msg.to,"เรียบร้อย")
                    else:
                        nadya.sendMessage(msg.to,"คุณไม่มีอำนาจสั่ง")
        
                elif text.lower() == 'เพิ่มดำ':
                    if msg._from in admin:
                        settings["wblacklist"] = True
                        nadya.sendMessage(msg.to,"Send Contact")
                    else:
                        nadya.sendMessage(msg.to,"คุณไม่มีอำนาจสั่ง")
         
                elif msg.text in ["เพิ่มขาว"]:
                    if msg._from in admin:
                        settings["dblacklist"] = True
                        nadya.sendMessage(msg.to,"Send Contact")
                    else:
                        nadya.sendMessage(msg.to,"คุณไม่มีอำนาจสั่ง")
#-------------------------------------------------------------------------------
                elif msg.text.lower() == "ล้างเชิญ":
                    if msg._from in admin:
                        group = nadya.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for i in gMembMids:
                            random.choice(KAC).cancelGroupInvitation(msg.to,[i])
                        else:
                            nadya.sendMessage(msg.to, "*เรียบร้อย*")
                elif msg.text in ["เชิญ"]:
                    if msg._from in admin:
                        settings["winvite"] = True
                        nadya.sendMessage(msg.to,"ส่งคอนแทคเพื่อเชิญได้เลยคับ")
                    else:
                        nadya.sendMessage(msg.to,"คุณไม่มีอำนาจสั่ง")
#-------------------------------------------------------------------------------
                elif text.lower() == 'บัญชีดำ':
                    if msg._from in admin:
                        if settings["blacklist"] == {}:
                            nadya.sendMessage(msg.to,"ไม่พบผู้ติดดำ")
                        else:
                            nadya.sendMessage(msg.to,"กำลังโหลด......")
                            num=1
                            msgs="══════════List Blacklist═════════"
                            for mi_d in settings["blacklist"]:
                                msgs+="\n[%i] %s" % (num, nadya.getContact(mi_d).displayName)
                                num=(num+1)
                            msgs+="\n══════════List Blacklist═════════\n\nผู้ติดบัญชีดำทั้งหมด :  %i" % len(settings["blacklist"])
                            nadya.sendMessage(msg.to, msgs)
#-------------------------------------------------------------------------------
                elif text.lower() == 'เช็คเพื่อน':
                    if msg._from in admin:
                        if settings["mid"] == {}:
                            nadya.sendMessage(msg.to,"*ไม่มี*")
                        else:
                            nadya.sendMessage(msg.to,"กำลังโหลด......")
                            num=1
                            msgs="══════════༺ஆืਹໂ√န༻═════════"
                            for mi_d in settings["mid"]:
                                msgs+="\n[%i] %s" % (num, nadya.getContact(mi_d).displayName)
                                num=(num+1)
                            msgs+="\n══════════༺ஆืਹໂ√န༻═════════\n\nทั้งหมด :  %i" % len(settings["mid"])
                            nadya.sendMessage(msg.to, msgs)

                elif 'เพิ่มเพื่อน' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               settings["mid"][target] = True
                               f=codecs.open('F__mid.json','w','utf-8')
                               json.dump(settings["mid"], f, sort_keys=True, indent=4,ensure_ascii=False)
                               nadya.sendMessage(msg.to,"สำเร็จ❋")
                               print ("update User")
                           except:
                               nadya.sendMessage(msg.to,"ผิดพลาด")
#=======================================================================================
                elif text.lower() == 'owner':
                    if msg._from in admin:
                        if Owner == []:
                            nadya.sendMessage(msg.to,"The Ownerlist is empty")
                        else:
                            nadya.sendMessage(msg.to,"กำลังโหลด...")
                            mc = "╔═══════════════\n╠♥ ✿✿✿ 🔥Hack Scan 🔔Win🔔  ✿✿✿ ♥\n╠══✪〘 Owner List 〙✪═══\n"
                            for mi_d in Owner:
                                mc += "╠✪ " +nadya.getContact(mi_d).displayName + "\n"
                            nadya.sendMessage(msg.to,mc + "╠═══════════════\n╠✪〘 line.me/ti/p/~vipscanner_win 〙\n╚═══════════════")
                elif 'เพิ่มเพื่อน' in text.lower():
                       targets = []
                       key = eval(msg.contentMetadata["MENTION"])
                       key["MENTIONEES"] [0] ["M"]
                       for x in key["MENTIONEES"]:
                           targets.append(x["M"])
                       for target in targets:
                           try:
                               settings["mid"][target] = True
                               f=codecs.open('F__mid.json','w','utf-8')
                               json.dump(settings["mid"], f, sort_keys=True, indent=4,ensure_ascii=False)
                               nadya.sendMessage(msg.to,"สำเร็จ❋")
                               print ("update User")
                           except:
                               nadya.sendMessage(msg.to,"ผิดพลาด")
#=======================================================================================
                elif text.lower() == 'admin':
                    if msg._from in admin:
                        if admin == []:
                            nadya.sendMessage(msg.to,"The Ownerlist is empty")
                        else:
                            nadya.sendMessage(msg.to,"กำลังโหลด...")
                            mc = "╔═══════════════\n╠♥ ✿✿✿ 🔥Hack Scan 🔔Win🔔  ✿✿✿ ♥\n╠══✪〘 admin List 〙✪═══\n"
                            for mi_d in admin:
                                mc += "╠✪ " +nadya.getContact(mi_d).displayName + "\n"
                            nadya.sendMessage(msg.to,mc + "╠═══════════════\n╠✪〘 line.me/ti/p/~vipscanner_win 〙\n╚═══════════════")
#=======================================================================================
                elif msg.text in ('/1','แทค'):
                  if msg._from in admin:
                    group = nadya.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    k = len(nama)//20
                    for a in range(k+1):
                        txt = u''
                        s=0
                        b=[]
                        for i in group.members[a*20 : (a+1)*20]:
                            b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                            s += 7
                            txt += u'@Alin \n'
                        nadya.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                    else:
                        nadya.sendMessage(to, "ทั้งหมด {}  คน".format(str(len(nama))))          
#=======================================================================================
        if op.type == 26:
            msg = op.message
            if settings ["Aip"] == True:
                if msg.text in ProtectMessage:
                    random.choice(KAC).kickoutFromGroup(receiver,[sender]not in admin)
                    nadya.sendMessage(msg.to,"ตรวจพบคำสั่งของบอทลบกลุ่ม\n           หรือ\n ตรวจพบคำพูดหยาบคายไม่สุภาพ\nจำเป็นต้องนำออกเพื่อความปลอดภัย\nและความสงบสุขของสมาชิก (｀・ω・´)")











                elif msg.text.lower().startswith("mid "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        lists = []
                        for mention in mentionees:
                            if mention["M"] not in lists:
                                lists.append(mention["M"])
                        ret_ = "[ Mid User ]"
                        for ls in lists:
                            ret_ += "\n{}" + ls
                        nadya.sendMessage(msg.to, str(ret_))
                elif text.lower() == 'mymid':
                    contact = nadya.getContact(sender)
                    nadya.sendMessage(msg.to, "{}".format(contact.MID))
